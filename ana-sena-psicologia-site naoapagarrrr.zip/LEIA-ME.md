# Ana Sena Psicologia — Site novo

## O que está incluído
- `index.html` — página inicial
- `ansiedade.html`, `relacionamentos.html`, `autoconhecimento.html` — páginas de área de atuação (cada uma com Schema FAQPage próprio)
- `privacidade.html` — Política de Privacidade (LGPD)
- `sitemap.xml` e `robots.txt` — para indexação no Google
- `favicon.ico` + ícones em `images/` — ícone que aparece na aba do navegador e ao salvar o site no celular
- `css/style.css` — todo o visual do site
- `js/main.js` — menu mobile, FAQ e animações leves

## ⚠️ Pendência importante: Google Analytics
Todas as páginas já têm o código do Google Analytics (GA4) inserido, mas com um ID de exemplo (`G-XXXXXXXXXX`). Para funcionar, você precisa:

1. Criar uma conta gratuita em https://analytics.google.com
2. Criar uma propriedade para `anasenapsicologia.com.br`
3. Copiar o ID que começa com `G-` (Measurement ID)
4. Substituir `G-XXXXXXXXXX` por esse ID em **todas as 4 páginas** (index, ansiedade, relacionamentos, autoconhecimento) — aparece 2 vezes em cada uma
5. Se preferir, eu faço essa substituição por você — só me mandar o ID

## Como publicar de graça no Cloudflare Pages

1. Crie uma conta gratuita em https://pages.cloudflare.com
2. No painel, clique em "Create a project" → "Upload assets"
3. Arraste esta pasta inteira (ou o .zip extraído)
4. Cloudflare vai gerar um link tipo `anasena.pages.dev` — funciona, mas o ideal é usar o domínio próprio
5. Em "Custom domains", adicione `anasenapsicologia.com.br` e `www.anasenapsicologia.com.br`
6. Você vai precisar trocar os registros DNS do domínio (onde ele foi comprado, ex: Registro.br) para apontar para o Cloudflare — o próprio painel te dá os valores exatos a inserir

## Antes de publicar definitivamente

- [x] Foto profissional real na seção Sobre
- [x] Imagem de capa para compartilhamento (`og-capa.jpg`)
- [x] Favicon
- [x] Política de Privacidade (LGPD)
- [ ] Inserir o ID real do Google Analytics (ver acima)
- [ ] Revisar todos os textos com a psicóloga antes do ar — o conteúdo foi escrito com cuidado ético, mas ela deve validar cada frase
- [ ] Testar o botão do WhatsApp em um celular real
- [ ] Depois de publicado, submeter o `sitemap.xml` no Google Search Console (gratuito) para acelerar a indexação

## Próximos passos recomendados (fora do site)

- Criar/reivindicar o perfil no Google Business Profile (business.google.com) — gratuito, e mais importante que o site para aparecer em buscas locais como "psicólogo Nova Iguaçu"
- Considerar perfil no Doctoralia, plataforma onde concorrentes da região já aparecem bem posicionados

