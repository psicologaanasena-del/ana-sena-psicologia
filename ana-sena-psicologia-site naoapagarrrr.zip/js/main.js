// Menu mobile
const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('nav');

if (menuToggle && nav) {
  menuToggle.addEventListener('click', () => {
    nav.classList.toggle('aberto');
    const expandido = nav.classList.contains('aberto');
    menuToggle.setAttribute('aria-expanded', expandido);
  });
}

// Fecha o menu mobile ao clicar em um link
document.querySelectorAll('nav a').forEach(link => {
  link.addEventListener('click', () => {
    nav?.classList.remove('aberto');
  });
});

// Animação de entrada suave ao rolar a página
const observador = new IntersectionObserver((entradas) => {
  entradas.forEach(entrada => {
    if (entrada.isIntersecting) {
      entrada.target.classList.add('visivel');
      observador.unobserve(entrada.target);
    }
  });
}, { threshold: 0.15 });

document.querySelectorAll('.surgir').forEach(el => observador.observe(el));
